%% ENEE313 Spring 2021 CAD2 - Philip Dodge
%% Part I
% a
clear;
pf = 8.854*10^-12; %permittivity of free space
h = 6.62607*10^-34;
hbar = h/(2*pi);
m = 9.109383*10^-31; % kg
q = 1.6021*10^-19; % e charge in C
a0 = (4*pi*pf*hbar^2)/(m*q^2);
r = linspace(0,14*10^-10,100);

% Hydrogen
Z = 1;
hunpsi = (1/sqrt(pi))*((Z/a0)^(3/2))*exp((-Z*r/a0));
doshunpsi = (1/(4*sqrt(2*pi)))*((Z/a0)^(3/2))*(2-((Z*r)/a0)).*exp((-Z*r)/(2*a0));

hunorb = (4*pi*r.^2).*hunpsi.^2;
doshunorb = (4*pi*r.^2).*doshunpsi.^2;

figure(1);
plot(r,hunorb);
title('Hydrogens 1s Orbital');
xlabel('r');
ylabel('probability density');
figure(2);
plot(r,doshunorb);
title('Hydrogens 2s Orbital');
xlabel('r');
ylabel('probability density');

% b
x = linspace(-1*10^-9,1*10^-9,100);
y = linspace(-1*10^-9,1*10^-9,100);
[X,Y] = meshgrid(x,y);

% PSI 100
f1 = (1/sqrt(pi)).*((Z/a0)^(3/2)).*exp((-Z*sqrt(X.^2 + Y.^2))/a0);
f12 = (f1.^2);
f1pd = (X.^2 + Y.^2).*f12;

figure(3);
pos1 = [0.5 0.15 0.4 0.7];
subplot('Position',pos1);
h = surf(X,Y,f1pd);
set(h,'EdgeColor', 'none');

pos2 = [0.1 0.3 0.3 0.3];
subplot('Position',pos2);
h = surf(X,Y,f1pd);
set(h,'EdgeColor', 'none');
view(2);
sgtitle('Psi 100');

% PSI 200
f2 = (1/(4*sqrt(2*pi)))*((Z/a0)^(3/2))*(2-((Z.*sqrt(X.^2 + Y.^2))/a0)).*exp((-Z.*sqrt(X.^2 + Y.^2))/(2*a0));
f22 = (f2.^2);
f2pd = (X.^2 + Y.^2).*f22;

figure(4); 
pos1 = [0.5 0.15 0.4 0.7];
subplot('Position',pos1);
h = surf(X,Y,f2pd);
set(h,'EdgeColor', 'none');

pos2 = [0.1 0.3 0.3 0.3];
subplot('Position',pos2);
h = surf(X,Y,f2pd);
set(h,'EdgeColor', 'none');
view(2);
sgtitle('Psi 200');

% PSI 210
f3 = (1/(4*sqrt(2*pi)))*((Z/a0)^(3/2))*(((Z.*sqrt(X.^2 + Y.^2))/a0)).*exp((-Z.*sqrt(X.^2 + Y.^2))/(2*a0)).*cos(X./(sqrt(X.^2 + Y.^2)));
f32 = (f3.^2);
f3pd = (X.^2 + Y.^2).*f32;

figure(5); 
pos1 = [0.5 0.15 0.4 0.7];
subplot('Position',pos1)
h = surf(X,Y,f3pd);
set(h,'EdgeColor', 'none');

pos2 = [0.1 0.3 0.3 0.3];
subplot('Position',pos2);
h = surf(X,Y,f3pd);
set(h,'EdgeColor', 'none');
view(2);
sgtitle('Psi 210');

% PSI 211
f4 = (1/(8*sqrt(2*pi)))*((Z/a0)^(3/2))*(((Z.*sqrt(X.^2 + Y.^2))/a0)).*exp((-Z.*sqrt(X.^2 + Y.^2))/(2*a0)).*sin(X./(sqrt(X.^2 + Y.^2)));
f42 = (f4.^2);
f4pd = (X.^2 + Y.^2).*f42;

figure(6); 
pos1 = [0.5 0.15 0.4 0.7];
subplot('Position',pos1)
h = surf(X,Y,f4pd);
set(h,'EdgeColor', 'none');

pos2 = [0.1 0.3 0.3 0.3];
subplot('Position',pos2);
h = surf(X,Y,f4pd);
set(h,'EdgeColor', 'none');
view(2);
sgtitle('Psi 211');

%% Part II
n = input('Enter an energy level n: ');
lb = input('Enter the length of the well in nm, ie 1,2,... ');
v0e = input('Enter well depth in eV: ');
fprintf('\n');

v0 = v0e*q; %ev to joules
l = lb*1*10^-9; 
parity = (-1)^n; %if n is even or odd
cnt = 0; %counter to track interations required

% infinite well stats
eiw = (hbar^2*pi^2*n^2)/(2*m*l^2); % infinite well in joules
kniw = sqrt(2*m*eiw)/hbar;
beta = sqrt(2*m*v0)/hbar;
knfw = 0.9*kniw; % 0.9 was the approximation used by Dr. Neil in class
deltaknfw = 1*10^9;

if(parity == -1) % even parity
    while abs(deltaknfw) > 1
        julius = knfw*tan((knfw*l)/2) - sqrt(beta^2 - knfw^2);
        augustus  = tan((knfw*l)/2) + ((knfw*l)/2)*(1/cos((l*knfw)/2)^2) + knfw/sqrt(beta^2 - knfw^2); % derivative like uncle like nephew 
        deltaknfw = -(julius/augustus); % blood thirsty senators
        knfw = knfw + deltaknfw;
        cnt = cnt + 1;
    end
    
elseif(parity == 1) % odd parity
    while abs(deltaknfw) > 1
        julius = -knfw*cot((knfw*l)/2) - sqrt(beta^2 - knfw^2);
        augustus = -cot((knfw*l)/2) + ((knfw*l)/2)*(1/sin((knfw*l)/2)^2) + knfw/sqrt(beta^2 - knfw^2); % derivative like uncle like nephew 
        deltaknfw = -(julius/augustus); % blood thirsty senators
        knfw = knfw + deltaknfw;
        cnt = cnt + 1;
    end
end

efw = (hbar^2*knfw^2)/(2*m*q); % finite well energy in eV

fprintf('Iterations: %.2f \n', cnt);
disp('Well    n-value    Energy(eV)    k-Value    Length L    Depth(eV)');
fprintf('Finite:    %d         %.4f     %.3e   %.3e      %d \n', n, efw, knfw, l, v0e);
fprintf('Infinite:  %d         %.4f     %.3e   %.3e      Inf \n', n, eiw/q, kniw, l);



