%% Philip Dodge CAD1 ENEE313 Spring 2021
%% Part I (G&D 1)
% Ein
clear all;
k = 4*pi*8.854*10^-12;
hbar = 1.054*10^-34; % Joules
q = 1.602*10^-19; % e Charge
m = 9.109*10^-31; % e Mass
z1 = 1; z2 = 2; z3 = 3;
Hydrogen = []; Helium = []; Lithium = [];

for n=1:4 % Calculates Hydrogen Radii
    r = (k*n^2*hbar^2)/(z1*q^2*m);
    Hydrogen = [Hydrogen r];
end
    
for n=1:4 % Calculates Helium Ion Radii
    r = (k*n^2*hbar^2)/(z2*q^2*m);
    Helium = [Helium r];
end
    
for n=1:4 % Calculates Lithium Ion Radii
    r = (k*n^2*hbar^2)/(z3*q^2*m);
    Lithium = [Lithium r];
end

T = table(Hydrogen', Helium', Lithium', 'VariableNames', {'Hydrogen', 'Helium', 'Lithium'}) % Meters

% Zwei
hev = 4.135*10^-15; % eV's
c = 3*10^8; % Speed of Light
pE = [];
lambda = []; IR = []; UV = []; VIS = []; 

for n=1:9 % Finds Energy and Wavelengths of Emitted Photons
    E = ((q^4*m)/(2*k^2*hbar^2))*(1/(n^2) - 1/100); % Joules
    E = E*(6.242*10^18); % eV'slambda4
    pE = [pE E]; 
    wolfda = (hev*c)/E;
    lambda = [lambda wolfda]; %meters
    
    if wolfda > 0.7*10^-6 % wavelength is infrared or longer
        IR = [IR wolfda];
    elseif wolfda <= 0.7*10^-6 && wolfda >= 0.4*10^-6 %wavelegnth is visible light
            VIS = [VIS wolfda];
    else %wavelegnth is ultraviolet or shorter
        UV = [UV wolfda];
    end 
end

disp('These infrared wavelengths were emitted by photons:');
disp(IR);

disp('These visible spectrum wavelengths were emitted by photons:');
disp(VIS);
disp('          ');

disp('These ultraviolet wavelengths were emitted by photons:');
disp(UV);

figure(1);
bar(pE);
xlabel('n');
ylabel('Energy in eVs');
title('Energy Difference Between n=10 and n=');

figure(2);
bar(lambda);
xlabel('n');
ylabel('Wavelength in Meters');
title('Wavelength of Emitted Photon Between n=10 and n=');

% Need to seperate into IR, UV, and Visible Wavelengths

% Use Zwei FOR loop to solve for HW1 P1.4
% HW P1.4
pE4 = [];
lambda4 = [];

for n=2:-1:1
    E = ((q^4*m)/(2*k^2*hbar^2))*(1/(n^2) - 1/16); % Joules
    E = E*(6.242*10^18); % eV's
    pE4 = [pE4 E]; %last entry is 4->1
    wolfda = (hev*c)/E;
    lambda4 = [lambda4 wolfda];
end

%% Part II: Photoelectric Efferct (G&D1)
Al = []; Au= []; Pt = []; Ni = []; Cu = []; % Hold energies
pfreak = []; % Holds frequencies

for wave=3000:-50:100 % Calculates Energy of Emitted Electrons From Metal (Aluminum)
   freq = c/(wave*10^-9); % Nanometer correction
   pfreak = [pfreak freq];
   E = hev*freq - 4.08;
   Al = [Al E];
end

for wave=3000:-50:100 % Gold
   freq = c/(wave*10^-9);
   E = hev*freq - 5.1;
   Au = [Au E];
end

for wave=3000:-50:100 % Platinum
   freq = c/(wave*10^-9);
   E = hev*freq - 6.35;
   Pt = [Pt E];
end

for wave=3000:-50:100 % Nickel
   freq = c/(wave*10^-9);
   E = hev*freq - 5.01;
   Ni = [Ni E];
end

for wave=3000:-50:100 % Copper
   freq = c/(wave*10^-9);
   E = hev*freq - 4.7;
   Cu = [Cu E];
end

figure(3);
plot(pfreak,Al,pfreak,Au,pfreak,Pt,pfreak,Ni,pfreak,Cu);
xlabel('Photon Frequency in Hz');
ylabel('Emitted Electron Energy in eVs');
title('Emitted Electron Energy vs Photon Frequency');

%% Part III: Infinite Potential Quantum Well (G&D2)
% Ein
L1 = []; L2 = [];

for n=1:4 % L1 is a well of L = 1nm; Loop Finds Electron Energy Levels for Infinite Well
    E = (hbar^2*pi^2*n^2)/(2*m*1*(10^-9)^2);
    E = E*(6.242*10^18); % eV's
    L1 = [L1 E];
end

for n=1:4 %L2 is a well of L = 2nm
    E = (hbar^2*pi^2*n^2)/(2*m*2*(10^-9)^2);
    E = E*(6.242*10^18); % eV's
    L2 = [L2 E]; % L2 is off, compared to textbook table found on page 39, by a factor of 2 yet I can't see why
end

n = [1 2 3 4];
T2 = table(n', L1', L2', 'VariableNames', {'n', 'L1', 'L2'}) 

% Zwei
L = 0.2*10^-9;
x = linspace(0,0.2*10^-9,100);

% Wavefunctions For First 4 States
wfun1 = sin((pi*x)/L)*sqrt(2/L); wfun2 = sin((2*pi*x)/L)*sqrt(2/L);
wfun3 = sin((3*pi*x)/L)*sqrt(2/L); wfun4 =sin((4*pi*x)/L)*sqrt(2/L);
pden = wfun1.^2; pden2 = wfun2.^2; pden3 = wfun3.^2; pden4 = wfun4.^2;

figure(4);
plot(x,pden,x,pden2,x,pden3,x,pden4);
xlabel('L');
ylabel('Probability Density');
title('Probability Density Versus Length L');

% Drei
syms y;
LBig = 2e-9;
wfuny1 = sin((pi*y)/LBig)*sqrt(2/LBig); wfuny2 = sin((2*pi*y)/LBig)*sqrt(2/LBig);
pdeny1 = wfuny1^2; pdeny2 = wfuny2^2;

LA = vpaintegral(pdeny1,y,[0 0.2e-9]); % LA-LD calculates the probability of finding the particle over a given distance
LB = vpaintegral(pdeny2,y,[0 0.2e-9]);
LC = vpaintegral(pdeny1,y,[0.9e-9 1.1e-9]);
LD = vpaintegral(pdeny2,y,[0.9e-9 1.1e-9]);

%T3 = table(LA', LB', LC', LD', 'VariableNames', {'LA', 'LB', 'LC', 'LD'}) 
% I tried to make a table for these values but because the variables were
% symbolic, MATLAB wouldn't display the values

% Vier
LQ = [];

for n=2:10 % finds L for different transitions
    temp = (sqrt(((hbar^2*pi^2)/(2*m*1.602*10^-19))*(n^2-1)));
    LQ = [LQ temp];
end

% From examining the vector LQ, it can be seen that the transition from
% 1->5 results in an L of approximately 3nm. 
