%% ENEE313 Spring 2021 CAD 5 - Philip Dodge 115949157
% Part I
clear;
q = 1.602*10^-19; %one coloumb
es0 = 8.854*10^-14; %permitivity of free space
esi = 11.7*es0; %Silicon permitivity
eox = 3.9*es0; %Silicon Oxide permitivity
k = 1.38064 * 10^-23; %boltzman
h = 6.62607 * 10^-34; %plancks
m = 9.109383 * 10^-31; %electron mass
vt0 = 0.026; %300K thermal voltage
ni = 10^10; %intrinsic carrier conc. at 300K
ch_mu = 500; %channel electron mobility
lamb = 0.02; %channel width modulation factor
tox = 20*10^-7; %oxide thickness
NdG = 10^19; %gate doping
Ld = 0.1*10^-4; %gate drain overlap

disp('Welcome to the Circus');
NaSub = input('Enter your preferred substrate doping: ');
L = input('Enter your prefered gate length in um, must be between 0.8 um and 100 um: ');
W = input('Enter your prefered gate width in um, must be between 2 um and 100 um: ');
vd = input('Enter a drain voltage less than 10V: ');
vg = input('Enter a gate voltage less than 10V: ');
vs = input('Enter a source voltage less than 10V: ');

cox = eox/tox; %oxide capacitance
phi0 = vt0*log((NaSub*NdG)/(ni^2)); %built in potential
phip = -vt0*log(NaSub/ni); %p-substrate built in potential
vth = (1/cox)*(4*q*esi*NaSub*abs(phip))^(1/2) + 2*abs(phip) - phi0; %threshold voltage
vgs = vg - vs;
vds = vd - vs;

if (vgs - vth) <= vd %SAT
    Id = ((ch_mu*cox*W)/(2*L))*(vgs - vth)^2; 
elseif (vgs - vth) > vd %TRIODE - If (vgs-vth) = vd, we will get the same Id with either equation
    Id = ((ch_mu*cox*W)/L)*((vgs - vth)*vds - (vds^2)/2);     
end
fprintf('Drain Current is %e Amps\n', Id);

%% Part II
disp('Enter new voltages so that the MOSFET from before is in saturation');
vd = input('Enter a drain voltage less than 10V: ');
vg = input('Enter a gate voltage less than 10V: ');
vs = input('Enter a source voltage less than 10V: ');

cox = eox/tox; %oxide capacitance
phi0 = vt0*log((NaSub*NdG)/(ni^2)); %built in potential
phip = -vt0*log(NaSub/ni); %p-substrate built in potential
vgs = vg - vs;
vds = vd - vs;

if (vgs - vth) > vd
    disp('User provided DC voltages do not meet n-channel MOSFET saturation requirements');
    disp('Wintermute shutting down...');
    return;
end
    
Id = ((ch_mu*cox*W)/(2*L))*(vgs - vth)^2; 

%small signal parameters
gm = ((2*ch_mu*cox*W*Id)/L)^(1/2);
g0 = lamb*Id;
r0 = 1/g0;
cgs = (2/3)*cox*L*W;
cgd = cox*Ld*W;

fprintf('Small Signal Transconductance: %f\n', gm);
fprintf('Output Resistance: %e\n', r0);
fprintf('Gate Source Capacitance: %e\n', cgs);
fprintf('Gate Drain Capaciatance: %e\n', cgd);

