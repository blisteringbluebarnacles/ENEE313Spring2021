%% ENEE313 Spring 2021 CAD 4 - Philip Dodge 115949157
%I - Intrinsic Carrier Concentration
clear;
q = 1.602*10^-19; %one coloumb
es0 = 8.854*10^-14; %permitivity of free space
vt0 = 0.026; %thermal voltage at room temp
k = 1.38064 * 10^-23; %boltzman
h = 6.62607 * 10^-34; %plancks
m = 9.109383 * 10^-31; %electron mass

T1 = input('Enter a temperature constraint in Kelvin: '); 
Eg1 = input('Enter the materials bandgap in eV: ');
me1 = input('Enter an electrons effective mass ratio: ');
mp1 = input('Enter a holes effective mass ratio: ');

Eg1 = Eg1*q; %eV to Joules
vt1 = (k*T1)/q; %thermal voltage
mp1 = mp1*m; %holes effective mass
me1 = me1*m; %electrons effective mass
Nc1 = 2*((2*pi*me1*k*T1)/(h^2))^(3/2); 
Nv1 = 2*((2*pi*mp1*k*T1)/(h^2))^(3/2);
ni1 = sqrt(Nc1*Nv1)*exp((-Eg1)/(2*k*T1)); %intrinsic carrier conc at T1
ni1 = ni1*10^-6; %centimeter conversion
fprintf('Intrinsic Carrier Concentration: %e\n', ni1);

%II - Built-In Potential & Depletion Region
nd1 = input('Enter the donor dopant concentration: ');
na1 = input('Enter the acceptor dopant concentration: ');
es1 = input('Enter the permitivity of the material as a scaler: ');

es1 = es1*es0; %Permitivity of matierial
pbi1 = vt1*log((nd1*na1)/(ni1^2)); %built in potential
xn1 = sqrt((((2*es1*pbi1))/q)*(na1/(nd1*(na1+nd1)))); %how far depletion region extends into N-Side
xp1 = sqrt((((2*es1*pbi1))/q)*(nd1/(na1*(na1+nd1)))); %how far depletion region extends into P-Side
width1 = xn1+xp1; %Total DR legnth

%III - Plot Electric Field, Potential, Charge Concentration
disp('Internal Electric Field - Enter 1');
disp('Electrostatic Potential - Enter 2');
disp('Charge Concentration - Enter 3');
choice1 = input('Which of the aformentioned data would you like to calculate and graph: ');
 
x1 = linspace(-xn1,0,50);
x2 = linspace(0,xp1,50);
 
 switch choice1
     case 1 %Electric Field
         en1 = (q/es1)*nd1*(xn1 + x1); %N-Side E-Field equation
         ep1 = (q/es1)*na1*(xp1 - x2); %P-Side E-Field equation
         figure(1)
         plot(x1,en1,x2,ep1)
         xline(0);
         xlabel('Position');
         ylabel('Energy');
         title('PN Junction Energy VS Position');
     case 2 %Electrostatic Potential
         phip1 = -vt1*log(na1/ni1); %P-Side Potential Constant w/out applied voltage
         phin1 = vt1*log(nd1/ni1); %N-Side Potential Constant
         phiL1 = phin1 - (q/(2*es1))*nd1*(xn1 + x1).^2; %N-Side Potential as a function of position
         phiR1 = phip1 + (q/(2*es1))*na1*(xp1 - x2).^2; %P-Side Potential as a function of position
         figure(2);
         plot(x1,phiL1,x2,phiR1)
         yline(phin1);
         yline(phip1);
         yline(0);
         xline(0);
         xlabel('Position');
         ylabel('ElectroStatic Potential');
         title('PN Junction ES Potential VS Position');
     case 3 %Charge Concentration
         hold on
         figure(3);
         rectangle('Position',[-xn1 0 xn1 nd1],'EdgeColor','b');
         rectangle('Position',[0 -na1 xp1 na1],'EdgeColor','r');
         xline(0); yline(0);
         xlabel('Position x');
         ylabel('p/q');
         title('Charge Concentration vs Position');  
 end
 
%% IV - I,II,III but with an applied voltage
T1 = input('Enter a temperature constraint in Kelvin: '); 
Eg1 = input('Enter the materials bandgap in eV: ');
me1 = input('Enter an electrons effective mass ratio: ');
mp1 = input('Enter a holes effective mass ratio: ');

Eg1 = Eg1*q;
vt1 = (k*T1)/q;
mp1 = mp1*m;
me1 = me1*m;
Nc1 = 2*((2*pi*me1*k*T1)/(h^2))^(3/2);
Nv1 = 2*((2*pi*mp1*k*T1)/(h^2))^(3/2);
ni1 = sqrt(Nc1*Nv1)*exp((-Eg1)/(2*k*T1));
ni1 = ni1*10^-6; %centimeter conversion
fprintf('Intrinsic Carrier Concentration: %e\n', ni1);

nd1 = input('Enter the donor dopant concentration: ');
na1 = input('Enter the acceptor dopant concentration: ');
es1 = input('Enter the permitivity of the material as a scaler: ');
va1 = input('Enter an applied bias in volts, must be less than built-in potential: ');

es1 = es1*es0;
pbi1 = vt1*log((nd1*na1)/(ni1^2));
xn1 = sqrt((((2*es1*(pbi1-va1)))/q)*(na1/(nd1*(na1+nd1)))); %Applied
xp1 = sqrt((((2*es1*(pbi1-va1)))/q)*(nd1/(na1*(na1+nd1)))); %Applied
width1 = xn1+xp1;

disp('Internal Electric Field - Enter 1');
disp('Electrostatic Potential - Enter 2');
disp('Charge Concentration - Enter 3');
choice1 = input('Which of the aformentioned data would you like to calculate and graph: ');

x1 = linspace(-xn1,0,50);
x2 = linspace(0,xp1,50);
 
 switch choice1
     case 1 %Electric Field
         en1 = (q/es1)*nd1*(xn1 + x1); 
         ep1 = (q/es1)*na1*(xp1 - x2);
         figure(4)
         plot(x1,en1,x2,ep1)
         xline(0);
         xlabel('Position');
         ylabel('Energy');
         title('PN Junction Energy VS Position with Applied Voltage');
     case 2 %Electrostatic Potential
         phip1 = -vt1*log(na1/ni1) + va1; %Pg. 151 Add Va
         phin1 = vt1*log(nd1/ni1);
         phiL1 = phin1 - (q/(2*es1))*nd1*(xn1 + x1).^2;
         phiR1 = phip1 + (q/(2*es1))*na1*(xp1 - x2).^2;
         figure(5);
         plot(x1,phiL1,x2,phiR1)
         yline(phin1);
         yline(phip1);
         yline(0);
         xline(0);
         xlabel('Position');
         ylabel('ElectroStatic Potential');
         title('PN Junction ES Potential VS Position with Applied Voltage');
     case 3 %Charge Concentration
         hold on
         figure(6);
         rectangle('Position',[-xn1 0 xn1 nd1],'EdgeColor','b');
         rectangle('Position',[0 -na1 xp1 na1],'EdgeColor','r');
         xline(0); yline(0);
         xlabel('Position x');
         ylabel('p/q');
         title('Charge Concentration vs Position');
 end

%% V Carrier Concentration and Current
Ln1 = 10*10^-6*10^2; %electron recombination legnth
Lp1 = 10*10^-6*10^2; %hole reconmbination length - may need unit conversion, think its in cm
muN = 1000; %electron mobility - cm^2/Vsec
muP = 500; %hole mobility - cm^2/Vsec
A = 100*10^-6*100*10^-6*10^2; %area in cm^2

disp('...The program will take all but one value from the previous section');
va2 = input('Enter an applied bias in volts, must be less than built-in potential: ');

%Minority Carrier Concentration Calculations and Plot
np01 = (ni1^2)/na1; %electrons on pside
pn01 = (ni1^2)/nd1; %holes on nside
xn2 = sqrt((((2*es1*(pbi1-va2)))/q)*(na1/(nd1*(na1+nd1)))); %2nd Applied
xp2 = sqrt((((2*es1*(pbi1-va2)))/q)*(nd1/(na1*(na1+nd1)))); %2nd Applied
x5n = linspace(-xn2,0,100);
x5p = linspace(0,xp2,100);
deltan = np01*(exp(va2/vt1) - 1)*exp((xp2-x5p)/Ln1); %electron concentration
deltap = pn01*(exp(va2/vt1) - 1)*exp((xn2+x5n)/Lp1); %hole concentration

figure(7);
plot(x5p,deltan,x5n,deltap);
xline(0); xline(xp2); xline(-xn2);
xlabel('Position');
ylabel('Minority Carrier Concentration');
title('Minority Carrier Concentration vs Position');
legend('Electron Concentration','Hole Concentration','Location','southwest');

%Electron and Hole Current Density Calculations and Plot
Dn = (muN)*(vt1);
Dp = (muN)*(vt1); %Einstein equation
x5device = linspace(-xn2-(3*10^-3),xp2+(3*10^-3),1000); %approximation of the device length

deltan2 = np01*(exp(va2/vt1) - 1)*exp((xp2-x5device)/Ln1); %electron concentration - need to redo b/c we are now plotting the entire device
deltap2 = pn01*(exp(va2/vt1) - 1)*exp((xn2+x5device)/Lp1); %hole concentration 

Jnp = ((q*Dn)/Ln1)*deltan2; %electron currenty density in quasi-netural P-Side
Jpn = ((q*Dp)/Lp1)*deltap2; %hole currenty density in quasi-netural N-Side
Inp = A*Jnp;
Ipn = A*Jpn;
Jtot = (((q*Dp*pn01)/Lp1) + ((q*Dn*np01)/Ln1))*(exp(va2/vt1) - 1); %total current density
Itot = A*Jtot;

fprintf('Terminal Diode Current = %e/n', Itot);

MajorN = Itot-Ipn;
MajorP = Itot-Inp;

figure(8);
plot(x5device,MajorN,x5device,MajorP);
yline(0); xline(0);
yline(Itot);
legend('Electron Current','Hole Current','Location','southwest');
title('Mobile Carrier Current vs Position');
ylabel('Current');
xlabel('Position');


%% VI Diode Current vs Voltage
ni300 = 10^10; %intrinsic carrier conc. at 300K

disp('You will now be asked to specify a voltage range for the diode current');
disp('Remember, neither bound can exceed the build-in potential');
disp('Room temperature conditions are present');
LBound = input('Enter your lower bound in volts: ');
UBound = input('Enter your upper bound in volts: ');

va6 = linspace(LBound,UBound,1000);

np06 = (ni300^2)/na1; %electrons on pside
pn06 = (ni300^2)/nd1; %holes on nside
Dn300 = (muN)*(vt0); %Einstein equation
Dp300 = (muN)*(vt0); %Einstein equation

Io300 = (((q*Dp300*pn06)/Lp1) + ((q*Dn300*np06)/Ln1))*A;
Id300 = Io300*(exp(va6/vt0) - 1);

figure(9);
plot(va6,Id300);
xline(0);
title('Diode Current vs Applied Voltage when T=300K');
ylabel('Current Id');
xlabel('Applied Voltage Va');

%% VII
jmax = 10^7;

%N-Side Numerical Integration
dx = (0 - xn1)/jmax;
int = 0;
x(1)=-xn1;

for i=1:jmax
    x(i+1) = x(i)+dx;
end

for i=1:jmax
    fx1 = (q/es1)*nd1*(x(i));
    fx2 = (q/es1)*nd1*(x(i));
    fxav = (fx1+fx2)/2;
    int = int+fxav;
end  
intN = int*dx

%P-Side Numerical Integration
dx = (xp1 - 0)/jmax;
int = 0;
x(1)=0;
for i=1:jmax
    x(i+1) = x(i)+dx;
end

for i=1:jmax
    fx1 = (q/es1)*na1*(x(i));
    fx2 = (q/es1)*na1*(x(i));
    fxav = (fx1+fx2)/2;
    int = int+fxav;
end 
intP = int*dx

intT = intN + intP

phip1 = -vt1*log(na1/ni1) + va1 %Pg. 151 Add Va
phin1 = vt1*log(nd1/ni1)
phiTot = phip1 + phin1

% en1 = (q/es1)*nd1*(xn1 + x1); 
% ep1 = (q/es1)*na1*(xp1 - x2);