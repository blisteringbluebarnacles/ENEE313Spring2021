%% ENEE313 Spring 2021 MasterCode - Philip Dodge 115949157
while 1
    disp('Exit - Enter 0');
    disp('CAD Assignment One - Enter 1');
    disp('CAD Assignment Two - Enter 2');
    disp('CAD Assignment Four - Enter 4');
    disp('CAD Assignment Five - Enter 5');
    tuna = input('Which of the aformentioned programs would you like to run: ');
    
    switch tuna
        case 0
            break;
        case 1
            disp('Executing CAD Assingment One...');
            ENEE313_Spring_2021_CAD1
        case 2
            disp('Executing CAD Assingment Two...');
            ENEE313_Spring_2021_CAD2
        case 4
            disp('Executing CAD Assignment Four...');
            ENEE313_Spring_2021_CAD4_V2
        case 5
            disp('Executing CAD Assignment Five...');
            ENEE313_Spring_2021_CAD5
        otherwise
            disp('Not a valid input');          
    end
end
   
            
           
       